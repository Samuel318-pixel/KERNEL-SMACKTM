SMACKTM Kernel (Patched Version)
================================

Alterações aplicadas:
- Substituição de funções inseguras de string (`strcpy`, `strcat`, `strtok`) por versões seguras (`strncpy`, `strncat`, `strtok_r`).
- Comentários `/* SAFE */` inseridos nos locais modificados.
- Estrutura de diretórios recriada a partir do arquivo único.

Instruções para compilar no QEMU:
---------------------------------
1. Configure seu compilador cruzado (ex.: i686-elf-gcc).
2. No diretório raiz do kernel, execute:
   make
3. Para testar no QEMU:
   qemu-system-i386 -kernel kernel.bin
